package com.example.xinshuang.together


import android.content.Context
import android.view.View
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.xinshuang.together.Supplier.blogs
import kotlinx.android.synthetic.main.activity_travelblog.view.*

class blogAdapter(val homeFeed: HomeFeed) : RecyclerView.Adapter<blogAdapter.MyViewHolder>() {

    val videoTitles = listOf("First title", "second", "3rd", "MOOOOORE TITLE")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent?.context)
        val view = layoutInflater.inflate(R.layout.activity_travelblog,parent,false)
        return MyViewHolder(view)
    }
    override fun getItemCount(): Int {
        return homeFeed.videos.count()
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val video = homeFeed.videos.get(position)
        holder?.view?.theme.text = video.name
    }

    inner class MyViewHolder(val view: View) : RecyclerView.ViewHolder(view){

    }
}