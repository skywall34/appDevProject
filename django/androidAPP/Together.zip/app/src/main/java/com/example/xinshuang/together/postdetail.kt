package com.example.xinshuang.together

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class postdetail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_postdetail)
    }
}
