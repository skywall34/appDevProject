package com.example.xinshuang.together

data class blog(val theme:String, val detail:String)

object Supplier{
    val blogs = listOf<blog>(
            blog("Skiing", "hdhhdhhdhdhh"),
            blog("Jumping", "sssssssssss"),
            blog("swmming", "kkkkkkkkkkk"),
            blog("diving", "lllllllllllllllllllllllllllllllllllllllll")
    )
}